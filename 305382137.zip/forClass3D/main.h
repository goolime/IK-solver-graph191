#pragma once

int main(int argc, char ** argv);

void move_X_right();
void move_X_left();
void move_Z_right();
void move_Z_left();
void index_up();
void index_down();
void flip_solve();
void restart();
void picking(int pos_x, int pos_y);
void move_up();
void move_down();
void move_left();
void move_right();
void move_in();
void move_out();
void flip_euler();
void print_M();